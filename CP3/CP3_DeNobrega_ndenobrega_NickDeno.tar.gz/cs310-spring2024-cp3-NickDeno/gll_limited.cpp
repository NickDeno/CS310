#include <iostream>
using namespace std;
#include "Thing.h"
#include "goofy.h"
#include "GLL.h"
#include "GLL.cpp"
template class GLL<std::string>;
template class GLL<int>;
template class GLL<Thing>;
