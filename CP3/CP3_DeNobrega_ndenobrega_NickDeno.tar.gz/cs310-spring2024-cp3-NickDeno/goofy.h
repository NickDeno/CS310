#ifndef __IS_GOOFY__
#define __IS_GOOFY__

#include<string>
#include<iostream>

bool isGoofy(int a);
bool isGoofy(std::string a);

#endif
