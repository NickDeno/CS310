#include <iostream> 
using namespace std;

#include "goofy.h"
#include "Thing.h"
#include "GLL.h"

int main() {
	GLL<int> gints;
	GLL<string> gtrings;
	GLL<Thing> gthings;
}
