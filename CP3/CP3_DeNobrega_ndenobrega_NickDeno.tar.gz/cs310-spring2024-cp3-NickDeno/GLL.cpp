#ifndef GLL_cpp
#define GLL_cpp
#include "goofy.h"
#include "GLL.h"

template<typename T>
bool GLL<T>::contains(const T& value) const {
    Node* current = head;
    while (current != nullptr) {
        if (current->data == value)
            return true;
        current = current->next;
    }
    return false;
}

template<typename T>
GLL<T>::GLL() : head(nullptr), tail(nullptr), current(nullptr) {}  

template<typename T> 
GLL<T>::~GLL() {
    flush();
}

template<typename T>
bool GLL<T>::isEmpty() const {
    return head == nullptr;
}

template<typename T>
bool GLL<T>::flush() {
    while (head != nullptr) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
    tail = nullptr;
    return true;
}

template<typename T>
bool GLL<T>::prepend(const T& item) {
    Node* newNode = new Node(item);
    if (!newNode)
        return false;
    
    if (isEmpty()) {
        head = tail = newNode;
    } else {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
    return true;
}

template<typename T>
bool GLL<T>::append(const T& item) {
    Node* newNode = new Node(item);
    if (!newNode)
        return false;
    
    if (isEmpty()) {
        head = tail = newNode;
    } else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
    return true;
}

template<typename T>
bool GLL<T>::merge(GLL &other) {
    // If merging with itself or other is empty, do nothing
    if (this == &other || other.isEmpty()){
        return true;
    } else if (isEmpty()) {
        head = other.head;
        tail = other.tail;
    } else {
        // Attach other's head to the end of the current list
        tail->next = other.head;
        other.head->prev = tail;
        tail = other.tail;
    }
    other.head = nullptr;
    other.tail = nullptr;
    return true;
}

template<typename T>
GLL<T>& GLL<T>::operator+=(const GLL<T>& other) {
    if (this == &other || other.isEmpty()){
        return *this;
    }else {
        Node* temp = other.head;
        while(temp != nullptr){
            this->append(temp->data);
            temp = temp->next;
        }
    }
    return *this;
}

template<typename T>
GLL<T>& GLL<T>::operator-=(const GLL<T>& other) {
    if (this == &other || other.isEmpty())
        return *this;

    Node* current = head;
    while (current != nullptr) {
        if (other.contains(current->data)) {
            Node* temp = current;
            current = current->next;
                //Temp is not head element
            if (temp->prev != nullptr)
                temp->prev->next = temp->next;
            //Temp is head element
            else
                head = temp->next;

            //Temp is not tail element
            if (temp->next != nullptr)
                temp->next->prev = temp->prev;
            //Temp is tail element
            else
                tail = temp->prev;
            delete temp;
        } else {
            current = current->next;
        }
    }
    return *this;
}

template<typename T>
int GLL<T>::purgeGoofy() {
    int count = 0;
    Node* current = head;
    while (current != nullptr) {
        if (isGoofy(current->data)) {
            Node* temp = current;
            current = current->next;
                //Temp is not head element
            if (temp->prev != nullptr)
                temp->prev->next = temp->next;
            //Temp is head element
            else
                head = temp->next;

            //Temp is not tail element
            if (temp->next != nullptr)
                temp->next->prev = temp->prev;
            //Temp is tail element
            else
                tail = temp->prev;
            delete temp;
            count++;
        } else {
            current = current->next;
        }
    }
    return count;
}

template<typename T>
int GLL<T>::keepGoofy() {
    int count = 0;
    Node* current = head;
    while (current != nullptr) {
        if (!isGoofy(current->data)) {
            Node* temp = current;
            current = current->next;
            //Temp is not head element
            if (temp->prev != nullptr)
                temp->prev->next = temp->next;
            //Temp is head element
            else
                head = temp->next;

            //Temp is not tail element
            if (temp->next != nullptr)
                temp->next->prev = temp->prev;
            //Temp is tail element
            else
                tail = temp->prev;
            delete temp;
            count++;
        } else {
            current = current->next;
        }
    }
    return count;
}

template<typename T>
bool GLL<T>::demoteGoofy(){
    if (isEmpty()) return false;
    Node* current = head;
    while (current != nullptr) {
        if (isGoofy(current->data)) {
            // Remove current node from the list
            if (current->prev != nullptr)
                current->prev->next = current->next;
            else
                head = current->next;

            if (current->next != nullptr)
                current->next->prev = current->prev;
            else
                tail = current->prev;

            // Move current node to the back
            if (tail != nullptr) {
                tail->next = current;
                current->prev = tail;
                current->next = nullptr;
                tail = current;
            } else {
                head = tail = current;
                current->prev = nullptr;
                current->next = nullptr;
            }
        }
        current = current->next;
    }
    return true;
}

template<typename T>
bool GLL<T>::reset() {
    if (head != nullptr) {
        current = head;
        return true;
    } else {
        current = nullptr;
        return false;
    }
}

template<typename T>
bool GLL<T>::finished() {
    return current == nullptr;
}

template<typename T>
T GLL<T>::proceed() {
    if (finished())
    //"proceed() should return an item created with its default constructor."
    //?? not sure if this is right
        return T();
    T value = current->data;
    current = current->next;
    return value;
}

#endif // GLL_CPP